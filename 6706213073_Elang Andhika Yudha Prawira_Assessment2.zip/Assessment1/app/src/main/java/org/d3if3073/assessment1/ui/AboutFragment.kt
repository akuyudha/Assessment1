package org.d3if3073.assessment1.ui

import androidx.fragment.app.Fragment
import org.d3if3073.assessment1.R

class AboutFragment: Fragment(R.layout.about_fragment)