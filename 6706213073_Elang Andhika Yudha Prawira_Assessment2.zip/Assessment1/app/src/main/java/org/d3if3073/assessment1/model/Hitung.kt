package org.d3if3073.assessment1.model

data class Hitung(
    val bil1: Float,
    val bil2: Float,
    val operator: String
)
