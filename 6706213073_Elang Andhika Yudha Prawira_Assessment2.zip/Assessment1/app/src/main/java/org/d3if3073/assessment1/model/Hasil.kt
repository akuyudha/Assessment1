package org.d3if3073.assessment1.model

data class Hasil(
    val hasil: Float
)
